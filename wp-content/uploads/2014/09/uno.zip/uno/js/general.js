jQuery(document).ready(function(){
	jQuery( '.hero .hero-container' ).addClass( 'animated fadeInUp' );
});